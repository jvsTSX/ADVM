# ADVM
Audio Driver for (dreamcast) VMu

port and cut-down version of ADPM for the Dreamcast VMU, written entirely in LC86000 assembly language. 
use waterbear in order to assemble the source (https://github.com/wtetzner/waterbear), 
example song also comes in binary form, use elysian EVMU to run the binary if you want to take a quick look

notice SFR.I is not made by me, it's originally at https://github.com/jahan-addison/snake
